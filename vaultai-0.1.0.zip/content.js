(function(){function e(e){return new Promise((t,n)=>{chrome.runtime.sendMessage(e,e=>{let r=chrome.runtime.lastError;r?n(Error(r.message)):e?e.ok?t(e.data):n(Error(e.error)):n(Error(`EMPTY_RESPONSE`))})})}var t=new Set([`text`,`email`,`tel`,``]),n=new Set([`password`,`search`,`hidden`,`submit`,`button`,`reset`,`checkbox`,`radio`,`file`,`range`,`color`,`date`,`datetime-local`,`month`,`week`,`time`,`number`,`url`]);function r(e){if(e.hidden||e.closest(`[aria-hidden="true"]`)||e.closest(`[inert]`))return!1;let t=getComputedStyle(e);return t.display!==`none`&&t.visibility!==`hidden`}function i(e){return!e.disabled&&!e.readOnly&&r(e)}function a(e){return(e.getAttribute(`autocomplete`)??``).toLowerCase().split(/\s+/)}function o(e){return e instanceof HTMLInputElement&&e.type===`password`&&i(e)}function s(e){if(!(e instanceof HTMLInputElement)||!i(e)||n.has(e.type)||e.type===`password`)return!1;if(a(e).includes(`username`)||a(e).includes(`email`))return!0;if(t.has(e.type)){let t=`${e.name} ${e.id} ${e.getAttribute(`placeholder`)??``}`;return!/search|query|filter/i.test(t)||/user|email|login|phone|mail/i.test(t)}return!1}function c(e,t){for(let n=t-1;n>=0;--n){let t=e[n];if(t&&s(t))return t}return null}function l(e,t=3){let n=e.previousElementSibling,r=0;for(;n&&r<t;){if(s(n))return n;let e=n.querySelector(`input`);if(s(e))return e;n=n.previousElementSibling,r+=1}return null}function u(e){let t=e.closest(`form`);if(t){let n=[...t.querySelectorAll(`input`)],r=c(n,n.indexOf(e));if(r)return r}let n=l(e);if(n)return n;let r=[...e.ownerDocument.querySelectorAll(`input`)],i=r.indexOf(e);return i>0?c(r,i):null}function d(e){let t=[...(e.closest(`form`)??e.ownerDocument).querySelectorAll(`input`)],n=t.indexOf(e);for(let e=n+1;e<t.length;e+=1){let n=t[e];if(n&&o(n))return n}let r=e.nextElementSibling,i=0;for(;r&&i<3;){if(o(r))return r;let e=r.querySelector(`input`);if(o(e))return e;r=r.nextElementSibling,i+=1}return null}function f(e=document){let t=[...e.querySelectorAll(`input[type="password"]`)].filter(o).at(-1);if(!t)return null;let n=u(t);return n?{username:n,password:t}:{password:t}}function p(e){if(o(e)){let t=u(e);return t?{username:t,password:e}:{password:e}}if(s(e)){let t=d(e);return t?{username:e,password:t}:null}return null}var m=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,`value`)?.set;function h(e,t){m?m.call(e,t):e.value=t,e.dispatchEvent(new Event(`input`,{bubbles:!0})),e.dispatchEvent(new Event(`change`,{bubbles:!0}))}function g(e,t){e.username&&t.username!==void 0&&h(e.username,t.username),h(e.password,t.password)}var _=null;function v(e){_=e}function y(e){return _!==null&&_===e}var b=`vaultai-chip-host`,x=null,S=null,C=null,w=null,T=null,E=[],D=null,O=0;function k(e){if(!e)return``;try{return new URL(e).host}catch{return e}}function A(){if(x&&S&&C&&w)return!0;if(document.getElementById(b))return!1;x=document.createElement(`div`),x.id=b,x.style.cssText=`position:fixed;z-index:2147483647;top:0;left:0;display:none;`;let e=x.attachShadow({mode:`open`});return e.innerHTML=`
    <style>
      :host { all: initial; }
      .wrap {
        font-family: Inter, "IBM Plex Sans Arabic", system-ui, sans-serif;
        font-size: 13px;
        color: #ffffff;
        background: #192134;
        border: 1px solid rgba(255, 255, 255, 0.14);
        border-radius: 10px;
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.35);
        overflow: hidden;
        min-width: 190px;
      }
      .chip {
        display: flex;
        align-items: center;
        gap: 6px;
        width: 100%;
        padding: 8px 12px;
        border: 0;
        background: transparent;
        color: inherit;
        font: inherit;
        cursor: pointer;
      }
      .chip:hover { background: rgba(255, 255, 255, 0.06); }
      .list { display: flex; flex-direction: column; border-top: 1px solid rgba(255, 255, 255, 0.1); }
      .list[hidden] { display: none; }
      .row {
        display: flex;
        flex-direction: column;
        gap: 2px;
        padding: 8px 12px;
        border: 0;
        background: transparent;
        color: inherit;
        text-align: start;
        font: inherit;
        cursor: pointer;
      }
      .row:hover, .row:focus-visible { background: rgba(255, 255, 255, 0.08); }
      .title { font-weight: 600; }
      .sub { font-size: 11px; color: #94a3b8; }
    </style>
    <div class="wrap">
      <button class="chip" type="button">VaultAI</button>
      <div class="list" hidden></div>
    </div>`,S=e.querySelector(`.wrap`),C=e.querySelector(`.chip`),w=e.querySelector(`.list`),!S||!C||!w?!1:(C.addEventListener(`click`,()=>{w&&(w.hidden=!w.hidden)}),w.addEventListener(`click`,e=>{let t=e.target?.closest(`button[data-entry-id]`);if(!t)return;let n=t.dataset.entryId;n&&I(n)}),document.documentElement.appendChild(x),!0)}function j(e){if(!x)return;let t=e.getBoundingClientRect();x.style.top=`${Math.min(t.bottom+4,window.innerHeight-260)}px`,x.style.left=`${Math.max(4,Math.min(t.left,window.innerWidth-300))}px`}function M(){x&&(x.style.display=`block`)}function N(){O+=1,D!==null&&(window.clearTimeout(D),D=null),x&&(x.style.display=`none`),w&&(w.hidden=!0),E=[],T=null}function P(){if(w){w.replaceChildren();for(let e of E){let t=document.createElement(`button`);t.type=`button`,t.className=`row`,t.dataset.entryId=e.id;let n=document.createElement(`span`);n.className=`title`,n.textContent=e.title;let r=document.createElement(`span`);r.className=`sub`,r.textContent=e.username||k(e.urls[0]),t.append(n,r),w.append(t)}}}async function F(t){let n=++O,r;try{r=await e({type:`MATCH_ENTRIES`,url:location.href})}catch{N();return}n===O&&(E=r.entries,E.length===0?N():(C&&(C.textContent=`VaultAI · ${E.length}`),P(),w&&(w.hidden=!0),M()))}async function I(t){let n=T?.password.isConnected?T:f();if(n)try{let r=await e({type:`FILL_ENTRY`,id:t,url:location.href});g(n,r),v(r.password)}finally{N()}}function L(e){let t=e.target;if(!(t instanceof HTMLInputElement)||!o(t)&&!s(t))return;let n=p(t);n?(T=n,j(t),F(n)):N()}function R(e){let t=e.target;t instanceof HTMLInputElement&&(o(t)||s(t))&&(D!==null&&window.clearTimeout(D),D=window.setTimeout(()=>{D=null,x?.matches(`:hover`)||N()},150))}function z(){A()&&(document.addEventListener(`focusin`,L,!0),document.addEventListener(`focusout`,R,!0),document.addEventListener(`keydown`,e=>{e.key===`Escape`&&N()}))}var B=`vaultai-save-host`,V=null;function H(){V?.remove(),V=null}function U(t){H(),V=document.createElement(`div`),V.id=B,V.style.cssText=`position:fixed;z-index:2147483647;bottom:16px;inset-inline-end:16px;display:block;`;let n=V.attachShadow({mode:`open`});n.innerHTML=`
    <style>
      :host { all: initial; }
      .card {
        font-family: Inter, "IBM Plex Sans Arabic", system-ui, sans-serif;
        font-size: 13px;
        color: #ffffff;
        background: #192134;
        border: 1px solid rgba(255, 255, 255, 0.14);
        border-radius: 12px;
        box-shadow: 0 12px 32px rgba(0, 0, 0, 0.4);
        padding: 14px;
        width: 250px;
      }
      p { margin: 0; }
      .sub { margin-top: 4px; font-size: 11px; color: #94a3b8; word-break: break-all; }
      .actions { display: flex; gap: 8px; margin-top: 12px; }
      button {
        flex: 1;
        padding: 8px 10px;
        border-radius: 8px;
        border: 1px solid rgba(255, 255, 255, 0.14);
        font: inherit;
        cursor: pointer;
      }
      .save { background: #059669; border-color: #059669; color: #000000; font-weight: 600; }
      .dismiss { background: transparent; color: #ffffff; }
    </style>
    <div class="card" role="dialog" aria-label="Save password">
      <p>تحفظ الباسورد؟</p>
      <p class="sub"></p>
      <div class="actions">
        <button class="save" type="button" data-action="save">حفظ</button>
        <button class="dismiss" type="button" data-action="dismiss">مش دلوقتي</button>
      </div>
    </div>`;let r=n.querySelector(`.sub`);return r&&(r.textContent=t),n.addEventListener(`click`,t=>{let n=t.target?.closest(`button[data-action]`);if(!n)return;let r=n.dataset.action,i=V?.dataset.candidateId;i&&e(r===`save`?{type:`CONFIRM_SAVE`,candidateId:i}:{type:`DISMISS_SAVE`,candidateId:i}).catch(()=>void 0),H()}),document.documentElement.appendChild(V),V}async function W(t){let n;try{n=(await e({type:`SAVE_CANDIDATE`,url:t.url,username:t.username,password:t.password})).candidateId}catch{return}let r=U(t.username);r.dataset.candidateId=n}function G(e){let t=e.target instanceof HTMLFormElement?e.target:null,n=t?f(t):f();n&&window.setTimeout(()=>{let e=n.password.value,t=n.username?.value??``;e&&(y(e)||W({url:location.href,username:t,password:e}))},300)}function K(){document.addEventListener(`submit`,G,!0)}function q(){try{z(),K()}catch{}}document.readyState===`loading`?document.addEventListener(`DOMContentLoaded`,q,{once:!0}):q()})();